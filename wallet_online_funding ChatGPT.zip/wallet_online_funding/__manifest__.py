{
    "name": "Wallet Online Funding",
    "version": "1.0",
    "depends": ["website","contacts","point_of_sale"],
    "data": [
        "security/ir.model.access.csv",
        "data/ir_config.xml",
        "views/wallet_template.xml",
        "views/menu.xml"
    ],
    "installable": True
}